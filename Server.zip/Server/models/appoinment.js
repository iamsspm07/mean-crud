const myMongo = require("mongoose");

const Appoinment = myMongo.model("Appoinment", {
    Date: { type: String },
    Time: { type: String },
    Name: { type: String },
    Email: { type: String },
    Phone: { type: String },
    Address: { type: String }
});

module.exports = Appoinment;