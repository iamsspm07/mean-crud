const myMongo = require("mongoose");

const Formsignup = myMongo.model("Formsignup", {
    Name: { type: String },
    Email: { type: String },
    Phone: { type: String },
    Password: { type: String }
});

module.exports = Formsignup;