const myMongo = require("mongoose");

myMongo.connect("mongodb://localhost:27017/A2ZServices", (err) => {
    if (!err) {
        console.log("Welcome to MongoDataBase !!!!!!!!")
    } else {
        console.log("Connection Declined!! :- " + err);
    }
});

module.exports = myMongo;