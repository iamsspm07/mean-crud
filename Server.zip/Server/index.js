const myExpress = require("express");

const myBodyParser = require("body-parser");

const cors = require("cors");

const myMongoDB = require("./connectionDB.js");

//Import Route Module:
const routerSign = require("./routes/routerSignUp.js");
const routerAppoinment = require("./routes/appoinmentRoute.js");

const a2zService = myExpress();

a2zService.use(myBodyParser.json());

a2zService.use(cors({ origin: "http://localhost:4200" }));

a2zService.listen(3000, () => console.log("Server Is Running at Port: 3000"));

//Api Calls:
a2zService.use("/formsignup", routerSign);
a2zService.use("/appoinment", routerAppoinment);