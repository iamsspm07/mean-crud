const myExpress = require("express");

const routerAppoinment = myExpress.Router();

const ObjectId = require("mongoose").Types.ObjectId;

const Appoinment = require("../models/appoinment.js");



routerAppoinment.get("/all", (req, res) => {
    Appoinment.find((err, details) => {
        if (err) {
            console.log("Error occurs in Get Data: " + err);
        } else {
            res.send(details);
        }
    })
});



routerAppoinment.get("/:id", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {
        Appoinment.findById(req.params.id, (err, details) => {
            if (err) {
                console.log("Error occurs in GetById : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});



routerAppoinment.post("/add", (req, res) => {
    //Object Given through Parameter Constructor
    let appoin = new Appoinment({
        Date: req.body.Date,
        Time: req.body.Time,
        Name: req.body.Name,
        Email: req.body.Email,
        Phone: req.body.Phone,
        Address: req.body.Address
    });
    appoin.save((err, details) => {
        if (err) {
            console.log("Error in Post: " + err);
        } else {
            res.send(details);
        }
    })
});




routerAppoinment.put("/:id", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {

        let appoin = {
            Date: req.body.Date,
            Time: req.body.Time,
            Name: req.body.Name,
            Email: req.body.Email,
            Phone: req.body.Phone,
            Address: req.body.Address
        };
        Appoinment.findByIdAndUpdate(req.params.id, { $set: appoin }, { new: true }, (err, details) => {
            if (err) {
                console.log("Error occurs in Update By Id : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});



routerAppoinment.delete("/:id", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {
        Appoinment.findByIdAndRemove(req.params.id, (err, details) => {
            if (err) {
                console.log("Error occurs in DeleteById : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});



module.exports = routerAppoinment;
