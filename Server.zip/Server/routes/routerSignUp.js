const myExpress = require("express");

const routerSignup = myExpress.Router();

const ObjectId = require("mongoose").Types.ObjectId;

const Formsignup = require("../models/signUp.js");

//Get, post, put, Delete....
//Base Path: http://localhost:3000/registration

//Get all Details
routerSignup.get("/", (req, res) => {
    Formsignup.find((err, details) => {
        if (err) {
            console.log("Error occurs in Get Data: " + err);
        } else {
            res.send(details);
        }
    })
});

//Get By Id:
routerSignup.get("/:Email", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {
        Formsignup.findById(req.params.id, (err, details) => {
            if (err) {
                console.log("Error occurs in GetById : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});


//Post Api
routerSignup.post("/add", (req, res) => {
    //Object Given through Parameter Constructor
    let signup = new Formsignup({
        Name: req.body.Name,
        Email: req.body.Email,
        Phone: req.body.Phone,
        Password: req.body.Password
    });
    signup.save((err, details) => {
        if (err) {
            console.log("Error in Post: " + err);
        } else {
            res.send(details);
        }
    })
});


//put By Id:
routerSignup.put("/:id", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {

        let signup = {
            Name: req.body.Name,
            Email: req.body.Email,
            Phone: req.body.Phone,
            Password: req.body.Password
        };

        Formsignup.findByIdAndUpdate(req.params.id, { $set: signup }, { new: true }, (err, details) => {
            if (err) {
                console.log("Error occurs in Update By Id : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});



//Delete By Id:
routerSignup.delete("/:id", (req, res) => {
    if (ObjectId.isValid(req.params.id)) {
        Formsignup.findByIdAndRemove(req.params.id, (err, details) => {
            if (err) {
                console.log("Error occurs in DeleteById : " + err);
            } else {
                res.send(details);
            }
        });
    } else {
        return res.status(400).send("UserId Is Invalid :" + req.params.id);
    }
});

module.exports = routerSignup;